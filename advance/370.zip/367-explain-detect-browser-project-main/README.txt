ترتیب چک کردن مرورگرها

1. edge
2. firefox
3. opera
4. chrome
5. safari